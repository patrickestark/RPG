<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.0" name="HI" tilewidth="8" tileheight="8" tilecount="1600" columns="40">
 <image source="16X16/16X16.png" width="320" height="320"/>
</tileset>
